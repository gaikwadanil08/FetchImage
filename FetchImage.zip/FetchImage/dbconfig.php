
<?php

	$servername = "182.50.133.79:3306"
	$username = "laundry"
	$password = "laundry@7777"
	$dbname = "laundry"
	
	$con = mysql_connect($server, $user, $pass, $database);
	
?>